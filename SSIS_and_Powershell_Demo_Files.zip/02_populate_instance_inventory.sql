/* S.Kusen Feb 6, 2015

Use this script to input instances that you would like to connect to for purposes of the demo.

*/


USE [DEMO_DBAInventory]
GO

INSERT INTO [dbo].[instances] ([instance_name]) VALUES ('instance1')
INSERT INTO [dbo].[instances] ([instance_name]) VALUES ('instance2')
INSERT INTO [dbo].[instances] ([instance_name]) VALUES ('instance3')
INSERT INTO [dbo].[instances] ([instance_name]) VALUES ('instance4')
GO

